import pandas as pd,numpy as np,glob,json,hashlib,datetime
def sigmoid(x): return 1/(1+np.exp(-np.clip(x,-35,35)))
class LogisticRegression:
 def __init__(self,C=1,max_iter=500):self.C=C
 def fit(self,X,y):
  X=np.asarray(X,float);y=np.asarray(y,float);A=np.c_[np.ones(len(X)),X];pen=np.eye(A.shape[1])/self.C;pen[0,0]=0;b=np.zeros(A.shape[1])
  for _ in range(50):
   p=sigmoid(A@b);w=np.maximum(p*(1-p),1e-6);H=A.T@(w[:,None]*A)+pen;g=A.T@(p-y)+pen@b;step=np.linalg.solve(H,g);b-=step
   if np.max(np.abs(step))<1e-8:break
  self.coef_=b;return self
 def predict_proba(self,X):
  p=sigmoid(np.c_[np.ones(len(X)),np.asarray(X,float)]@self.coef_);return np.c_[1-p,p]
def log_loss(y,p):
 p=np.clip(np.asarray(p),1e-9,1-1e-9);y=np.asarray(y);return float(np.mean(-(y*np.log(p)+(1-y)*np.log(1-p))))
def brier_score_loss(y,p):return float(np.mean((np.asarray(p)-np.asarray(y))**2))
def accuracy_score(y,z):return float(np.mean(np.asarray(y)==np.asarray(z)))
def iso_fit(x,y):
 o=np.argsort(x);xs=np.asarray(x)[o];ys=np.asarray(y,float)[o];blocks=[[ys[i],1,i,i] for i in range(len(ys))]
 j=0
 while j<len(blocks)-1:
  if blocks[j][0]/blocks[j][1] > blocks[j+1][0]/blocks[j+1][1]:
   blocks[j]=[blocks[j][0]+blocks[j+1][0],blocks[j][1]+blocks[j+1][1],blocks[j][2],blocks[j+1][3]];blocks.pop(j+1);j=max(0,j-1)
  else:j+=1
 vals=np.empty(len(ys))
 for sm,n,a,b in blocks:vals[a:b+1]=sm/n
 def pred(z):return np.interp(np.asarray(z),xs,vals,left=vals[0],right=vals[-1])
 return pred

# PBP family dropped before any holdout run: reproducible enriched PBP coverage was not validated consistently through 2014-25.
# Exact ESPN schedule x betting IDs; betting archive defines eligible market-covered universe.
all=[]
for y in range(2014,2026):
 s=pd.read_csv(glob.glob(f'sched_{y}*')[0]);b=pd.read_csv(f'betting_{y}.csv.gz');d=s.merge(b[['game_id','home_team_spread','game_spread_available']],on='game_id',how='left'); d=d[(d.status=='STATUS_FINAL')&d.home_score.notna()&d.away_score.notna()].copy(); all.append(d)
d=pd.concat(all); fbs_by_year={y:set(pd.read_csv(f'espn_teams_{y}.csv').loc[lambda x:x.is_fbs==True,'team_id'].astype(str)) for y in range(2014,2026)}; d=d[d.apply(lambda r:str(r.home_id) in fbs_by_year[int(r.season)] and str(r.away_id) in fbs_by_year[int(r.season)],axis=1)].copy();d=d.sort_values(['game_date','game_id']).reset_index(drop=True);d['date']=pd.to_datetime(d.game_date,utc=True);d['target']=(d.home_score>d.away_score).astype(int);d['home_margin']=d.home_score-d.away_score
# sequential locked features
elo={};state={};last={};prevseason=None;rows=[]
for _,r in d.iterrows():
 if prevseason!=r.season:
  elo={t:.6*v+.4*1500 for t,v in elo.items()};prevseason=r.season
 h,a=str(r.home_id),str(r.away_id);he=elo.get(h,1500);ae=elo.get(a,1500);neutral=int(bool(r.neutral_site));hstate=state.get(h,[0,0,0]);astate=state.get(a,[0,0,0]);hr=(r.date-last[h]).days if h in last else 7;ar=(r.date-last[a]).days if a in last else 7
 rows.append(dict(elo_diff=he-ae,home_indicator=1-neutral,neutral=neutral,rest_diff=np.clip(hr-ar,-21,21),week=min(int(r.week),16),home_pf=hstate[0],away_pf=astate[0],home_pa=hstate[1],away_pa=astate[1],home_form_missing=int(h not in state),away_form_missing=int(a not in state)))
 # Elo no MOV, HFA 55
 ex=1/(1+10**(-((he+55*(1-neutral))-ae)/400));delta=20*(r.target-ex);elo[h]=he+delta;elo[a]=ae-delta
 for t,pf,pa in [(h,r.home_score,r.away_score),(a,r.away_score,r.home_score)]:
  old=state.get(t,[0,0,0]);state[t]=[.75*old[0]+.25*pf,.75*old[1]+.25*pa,old[2]+1];last[t]=r.date
F=['elo_diff','home_indicator','neutral','rest_diff','week','home_pf','away_pf','home_pa','away_pa','home_form_missing','away_form_missing'];d=pd.concat([d,pd.DataFrame(rows)],axis=1)
# fixed dev rolling selection, no holdout looked at during choice
Cs=[.01,.1,1,10];scores={}
for C in Cs:
 v=[]
 for yr in range(2018,2024):
  tr=d[(d.season<yr)&(d.season<=2023)];te=d[d.season==yr]
  mu=tr[F].mean();sd=tr[F].std().replace(0,1);m=LogisticRegression(C=C,max_iter=500).fit((tr[F]-mu)/sd,tr.target);v.append(log_loss(te.target,m.predict_proba((te[F]-mu)/sd)[:,1]))
 scores[C]=np.mean(v)
C=min(Cs,key=lambda c:(scores[c],-1/c))
# choose calibration once from rolling-origin 2018-2023 OOF development predictions
oy=[];op=[]
for yr in range(2018,2024):
 tr=d[d.season<yr];te=d[d.season==yr];mu=tr[F].mean();sd=tr[F].std().replace(0,1);mm=LogisticRegression(C=C).fit((tr[F]-mu)/sd,tr.target);op.extend(mm.predict_proba((te[F]-mu)/sd)[:,1]);oy.extend(te.target)
oy=np.asarray(oy);op=np.asarray(op);cal_train=np.arange(len(oy))%2==0;cal_test=~cal_train
pl=LogisticRegression(C=1e9).fit(np.log(np.clip(op[cal_train],1e-6,1-1e-6)/(1-np.clip(op[cal_train],1e-6,1-1e-6))).reshape(-1,1),oy[cal_train]);pi=iso_fit(op[cal_train],oy[cal_train])
cal_scores={'raw':log_loss(oy[cal_test],op[cal_test]),'platt':log_loss(oy[cal_test],pl.predict_proba(np.log(np.clip(op[cal_test],1e-6,1-1e-6)/(1-np.clip(op[cal_test],1e-6,1-1e-6))).reshape(-1,1))[:,1]),'isotonic':log_loss(oy[cal_test],pi(op[cal_test]))};calibration=min(cal_scores,key=cal_scores.get)
# spread benchmark trained curve, positive home_team_spread means home underdog based archive convention
results=[];predrows=[]
for yr in [2024,2025]:
 tr=d[d.season<yr];te=d[d.season==yr].copy();mu=tr[F].mean();sd=tr[F].std().replace(0,1);m=LogisticRegression(C=C,max_iter=500).fit((tr[F]-mu)/sd,tr.target);p=m.predict_proba((te[F]-mu)/sd)[:,1]
 # Fit locked calibrator shape on training-era rolling OOF only
 cy=[];cp=[]
 for vy in range(2018,yr):
  ctr=d[d.season<vy];cte=d[d.season==vy];cmu=ctr[F].mean();csd=ctr[F].std().replace(0,1);cm=LogisticRegression(C=C).fit((ctr[F]-cmu)/csd,ctr.target);cp.extend(cm.predict_proba((cte[F]-cmu)/csd)[:,1]);cy.extend(cte.target)
 cy=np.asarray(cy);cp=np.asarray(cp)
 if calibration=='platt':
  cc=LogisticRegression(C=1e9).fit(np.log(np.clip(cp,1e-6,1-1e-6)/(1-np.clip(cp,1e-6,1-1e-6))).reshape(-1,1),cy);p=cc.predict_proba(np.log(np.clip(p,1e-6,1-1e-6)/(1-np.clip(p,1e-6,1-1e-6))).reshape(-1,1))[:,1]
 elif calibration=='isotonic':p=iso_fit(cp,cy)(p)
 # fixed Elo baseline
 pe=1/(1+10**(-((te.elo_diff+55*te.home_indicator)/400)))
 spr=tr[tr.home_team_spread.notna()]; sm=LogisticRegression(C=1e6,max_iter=500).fit((-spr[['home_team_spread']]).values,spr.target); ps=sm.predict_proba((-te[['home_team_spread']]).values)[:,1]
 for name,q in [('model',p),('elo',pe),('spread_proxy',ps)]:
  logit=np.log(np.clip(q,1e-6,1-1e-6)/(1-np.clip(q,1e-6,1-1e-6)));cal=LogisticRegression(C=1e9).fit(np.asarray(logit).reshape(-1,1),te.target);results.append({'year':yr,'benchmark':name,'games':len(te),'log_loss':log_loss(te.target,q),'brier':brier_score_loss(te.target,q),'accuracy':accuracy_score(te.target,q>=.5),'calibration_intercept':float(cal.coef_[0]),'calibration_slope':float(cal.coef_[1])})
 for i,(_,r) in enumerate(te.iterrows()):predrows.append({'game_id':int(r.game_id),'season':yr,'week':int(r['week'].iloc[0] if hasattr(r['week'],'iloc') else r['week']),'date':r.game_date,'away_team':r.away_team,'home_team':r.home_team,'home_win':int(r.target),'home_spread':float(r.home_team_spread),'model_home_win_probability':float(p[i]),'elo_home_win_probability':float(pe.iloc[i] if hasattr(pe,'iloc') else pe[i]),'spread_proxy_home_win_probability':float(ps[i])})
# bootstrap model-spread and model-elo metric deltas
rng=np.random.default_rng(20260902);intervals=[]
for yr in [2024,2025]:
 q=[x for x in predrows if x['season']==yr];y=np.array([x['home_win'] for x in q]);pm=np.array([x['model_home_win_probability'] for x in q])
 for bench in ['elo_home_win_probability','spread_proxy_home_win_probability']:
  pb=np.array([x[bench] for x in q]);vals=[]
  for _ in range(10000):
   ix=rng.integers(0,len(y),len(y));yy=y[ix];a=np.clip(pm[ix],1e-9,1-1e-9);b=np.clip(pb[ix],1e-9,1-1e-9);vals.append([np.mean(-(yy*np.log(a)+(1-yy)*np.log(1-a))+yy*np.log(b)+(1-yy)*np.log(1-b)),np.mean((a-yy)**2-(b-yy)**2)])
  z=np.array(vals);intervals.append({'year':yr,'benchmark':bench.replace('_home_win_probability',''),'log_loss_delta_ci':[float(x) for x in np.quantile(z[:,0],[.025,.975])],'brier_delta_ci':[float(x) for x in np.quantile(z[:,1],[.025,.975])]})
res=pd.DataFrame(results);pivot=res.pivot(index='year',columns='benchmark',values=['log_loss','brier']);
# locked verdict both metrics beat Elo and not lose spread proxy each year
ok=True
for yr in [2024,2025]:
 z=res[res.year==yr].set_index('benchmark');ok &= z.loc['model','log_loss']<z.loc['elo','log_loss'] and z.loc['model','brier']<z.loc['elo','brier'] and z.loc['model','log_loss']<=z.loc['spread_proxy','log_loss'] and z.loc['model','brier']<=z.loc['spread_proxy','brier']
out={'schema_version':'1.0.0','spec_sha256':'5464effb6666b80b60bbeaa236cdc165a051f19ff6c78c3e702d1c1b88ab2b4a','generated_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'benchmark_downgrade':{'historical_paired_moneyline_coverage':0.0,'reason':'Free ESPN/SportsDataverse archive has no moneyline fields. Closing spread mapped through a training-era empirical win curve is used as a weaker proxy. No beat-the-moneyline-close claim is testable.'},'feature_drop_before_holdout':'Play-derived EPA/success/explosiveness/finishing drives/turnover/special-teams family dropped in full because consistent reproducible enriched PBP coverage through 2014-2025 was not validated. Locked remaining features were used.','selected_C_development_only':C,'development_C_scores':scores,'calibration_selected_development_only':calibration,'calibration_scores':cal_scores,'results':results,'bootstrap_intervals':intervals,'verdict':'promising_unsettled' if ok else 'descriptive_failed_close','holdout_rule':'2024 and 2025 reported separately; combined result cannot override a losing year.'}
json.dump(out,open('cfb_h2h_v1_holdout.json','w'),indent=2);pd.DataFrame(predrows).to_csv('cfb_h2h_v1_holdout_predictions.csv',index=False);print(json.dumps(out,indent=2))
