# E.D.I.T.H. CFB head-to-head v1 holdout report

Specification SHA-256: `5464effb6666b80b60bbeaa236cdc165a051f19ff6c78c3e702d1c1b88ab2b4a`

## Verdict

`descriptive_failed_close`

The model is better than the locked Elo baseline in both untouched years, but it loses decisively to the weaker closing-spread-derived probability benchmark in both years. It therefore fails the frozen promotion rule and is not an approved betting model.

## Sequential holdouts

| Year | Model | Games | Log loss | Brier | Accuracy |
|---|---|---:|---:|---:|---:|
| 2024 | H2H v1 | 798 | 0.5839 | 0.2008 | 68.30% |
| 2024 | Elo | 798 | 0.6268 | 0.2184 | 63.91% |
| 2024 | Spread proxy | 798 | 0.5318 | 0.1806 | 71.43% |
| 2025 | H2H v1 | 808 | 0.5578 | 0.1900 | 69.31% |
| 2025 | Elo | 808 | 0.6108 | 0.2105 | 67.70% |
| 2025 | Spread proxy | 808 | 0.5179 | 0.1752 | 73.39% |

Combined 2024-25 is reported only after the separate years: H2H v1 log loss 0.5708, Brier 0.1954; Elo 0.6187, 0.2144; spread proxy 0.5248, 0.1779. The combined result does not change the verdict.

Model-minus-Elo bootstrap 95% intervals exclude zero in the favorable direction for log loss and Brier in both years. Model-minus-spread intervals exclude zero in the unfavorable direction in both years. Full intervals and calibration buckets are in the result JSON.

## Data and benchmark limits

Historical paired closing moneyline coverage is 0%, so a claim that this model beats closing moneylines is not testable with the free archive. The spread proxy is a training-era empirical mapping from closing spread to home-win probability. It is weaker than a paired de-vigged moneyline close, but it covers all 798 eligible 2024 games and all 808 eligible 2025 games.

The universe is season-specific FBS-vs-FBS final games using the SportsDataverse ESPN team archive's `is_fbs` field. The play-derived feature family was dropped before holdout because consistent enriched play-by-play coverage through 2014-2025 was not established. The remaining locked model selected C=0.01 and raw probabilities using development data only.
