import pandas as pd,numpy as np,json,datetime,hashlib
AUD='espn_line_audit.csv'
# Explicit allowlists. Score/result/postgame columns are never selected.
CFB_SAFE=['game_id','season','week','season_type','game_date','neutral_site','home_id','away_id','home_team','away_team']
NFL_SAFE=['game_id','season','game_type','week','gameday','gametime','away_team','home_team','location','away_rest','home_rest','div_game','roof','surface','espn']
a=pd.read_csv(AUD,dtype={'game_id':str});a=a[(a.provider_name=='ESPN BET')]
def pairs(lg):
 z=a[a.league==lg].copy();z['open_spread']=pd.to_numeric(z.open_spread,errors='coerce');z['close_spread']=pd.to_numeric(z.close_spread,errors='coerce')
 h=z[z.side=='home'][['game_id','open_spread','close_spread']].rename(columns={'open_spread':'open','close_spread':'close'})
 w=z[z.side=='away'][['game_id','open_spread','close_spread']].rename(columns={'open_spread':'away_open','close_spread':'away_close'})
 q=h.merge(w,on='game_id');return q[q.open.notna()&q.away_open.notna()&q.close.notna()&q.away_close.notna()&((q.open+q.away_open).abs()<.01)&((q.close+q.away_close).abs()<.01)]
def base_matrix(d,teams,league):
 ti={t:i for i,t in enumerate(teams)};n=len(d);p=len(teams);X=np.zeros((n,p+5));
 for i,r in enumerate(d.itertuples()):X[i,ti[str(r.home_id)]]=1;X[i,ti[str(r.away_id)]]=-1
 X[:,p]=1 # intercept
 X[:,p+1]=d['home_field'].values
 X[:,p+2]=d['rest_diff'].values/7
 X[:,p+3]=np.minimum(d.week.values,16)/16
 X[:,p+4]=d['division_game'].values
 return X
def ridge(X,y,alpha,nteams):
 P=np.eye(X.shape[1])*alpha;P[nteams,nteams]=0 # intercept unpenalized
 return np.linalg.solve(X.T@X+P,X.T@y)
def run(d,league):
 d=d.sort_values(['week','date','game_id']).reset_index(drop=True);teams=sorted(set(d.home_id)|set(d.away_id));X=base_matrix(d,teams,league);y=d.open.values
 pred=np.full(len(d),np.nan);chosen=[]
 # Outer season-forward weeks. Nested prior-week selection among fixed ridge grid.
 for wk in sorted(d.week.unique()):
  te=np.where(d.week.eq(wk))[0];tr=np.where(d.week.lt(wk))[0]
  if len(tr)<100:continue
  candidates=[1,3,10,30,100]; scores={}
  prior=sorted(d.loc[tr,'week'].unique())
  for al in candidates:
   errs=[]
   for vw in prior[-4:]:
    vte=np.where(d.week.eq(vw))[0];vtr=np.where(d.week.lt(vw))[0]
    if len(vtr)<60:continue
    b=ridge(X[vtr],y[vtr],al,len(teams));errs.extend((y[vte]-X[vte]@b)**2)
   scores[al]=np.mean(errs) if errs else np.inf
  al=min(candidates,key=lambda q:(scores[q],q));b=ridge(X[tr],y[tr],al,len(teams));pred[te]=X[te]@b;chosen.append({'week':int(wk),'alpha':al,'train_n':len(tr),'test_n':len(te)})
 o=d[pd.notna(pred)].copy();o['fair_open']=pred[pd.notna(pred)];o['residual_actual_minus_fair']=o.open-o.fair_open;o['movement_close_minus_open']=o.close-o.open;o['abs_residual']=o.residual_actual_minus_fair.abs();o['abs_movement']=o.movement_close_minus_open.abs();o['correction_aligned']=np.sign(o.movement_close_minus_open)==-np.sign(o.residual_actual_minus_fair)
 r=o.residual_actual_minus_fair.values;m=o.movement_close_minus_open.values
 slope=float(np.dot(r-r.mean(),m-m.mean())/np.dot(r-r.mean(),r-r.mean()));corr=float(np.corrcoef(r,m)[0,1]);mae=float(np.mean(abs(y[pd.notna(pred)]-o.fair_open)))
 # permutation CI/null for correlation; seeded, no outcomes.
 rng=np.random.default_rng(20260902);pc=[]
 for _ in range(10000):pc.append(np.corrcoef(r,rng.permutation(m))[0,1])
 # block summaries predeclared by absolute residual magnitude
 o['residual_bucket']=pd.cut(o.abs_residual,[-.001,1,2,3,999],labels=['0-1','1-2','2-3','3+'])
 buck=o.groupby('residual_bucket',observed=True).agg(games=('game_id','size'),mean_abs_movement=('abs_movement','mean'),correction_rate=('correction_aligned','mean'),mean_movement=('movement_close_minus_open','mean')).reset_index().to_dict('records')
 met={'league':league,'paired_games':len(d),'rolling_oos_games':len(o),'rolling_oos_weeks':[int(o.week.min()),int(o.week.max())],'opener_mae_points':mae,'residual_movement_correlation':corr,'movement_on_residual_slope':slope,'correction_alignment_rate':float(o.correction_aligned.mean()),'mean_abs_movement':float(o.abs_movement.mean()),'permutation_null_correlation_95':[float(x) for x in np.quantile(pc,[.025,.975])],'residual_buckets':buck,'folds':chosen}
 return o,met
# CFB season-specific FBS only
s=pd.read_csv('/tmp/deep-research/cfb-h2h/sched_2025.csv.gz',usecols=CFB_SAFE);t=pd.read_csv('/tmp/deep-research/cfb-h2h/espn_teams_2025.csv',usecols=['team_id','is_fbs']);f=set(t.loc[t.is_fbs==True,'team_id'].astype(str));s=s[s.apply(lambda r:str(r.home_id) in f and str(r.away_id) in f,axis=1)];s['game_id']=s.game_id.astype(str);s['date']=pd.to_datetime(s.game_date,utc=True);s['home_id']=s.home_id.astype(str);s['away_id']=s.away_id.astype(str);s['home_field']=(~s.neutral_site.fillna(False)).astype(int);s['rest_diff']=0;s['division_game']=0
cf=s.merge(pairs('college-football'),on='game_id');co,cm=run(cf,'CFB')
# NFL regular season ESPN BET coverage; safe fields only
n=pd.read_csv('/tmp/games.csv',usecols=NFL_SAFE);n=n[(n.season==2025)&n.espn.notna()];n['game_id']=n.espn.astype(int).astype(str);n['date']=pd.to_datetime(n.gameday,utc=True);n['home_id']=n.home_team.astype(str);n['away_id']=n.away_team.astype(str);n['home_field']=n.location.eq('Home').astype(int);n['rest_diff']=n.home_rest-n.away_rest;n['division_game']=n.div_game.fillna(False).astype(int)
nf=n.merge(pairs('nfl'),on='game_id');no,nm=run(nf,'NFL')
for z,name in [(co,'cfb'),(no,'nfl')]:z[['game_id','week','date','away_team','home_team','open','fair_open','close','residual_actual_minus_fair','movement_close_minus_open','correction_aligned']].to_csv(f'{name}_2025_opener_rolling_predictions.csv',index=False)
out={'schema_version':'1.0.0','generated_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'label':'Market imitation / line-movement research; no outcomes; opener timestamps unavailable; not FanDuel-specific; no claim of beating the market.','data_boundary':'No outcomes, scores, winner fields, or postgame statistics selected or used.','results':[cm,nm]};json.dump(out,open('2025_fair_opener_results.json','w'),indent=2);print(json.dumps(out,indent=2))
