# 2025 fair-opener exploratory fit

**Market imitation / line-movement research; no outcomes; opener timestamps unavailable; not FanDuel-specific; no claim of beating the market.**

## Result

The residual is noise in both leagues. The model does not identify where the ESPN BET opener will move by close.

| League | Same-provider pairs | Strict rolling OOS games | OOS weeks | Fair-opener MAE | Residual vs movement correlation | Permutation null 95% | Moved-game correction rate |
|---|---:|---:|---|---:|---:|---:|---:|
| CFB | 751 | 607 | 4-14 | 4.71 pts | -0.029 | [-0.080, 0.080] | 50.0% |
| NFL | 193 | 85 | 8-13 | 2.37 pts | +0.074 | [-0.212, 0.211] | 55.7% |

CFB's movement-on-residual slope was -0.009: essentially zero. NFL's was +0.036, the wrong sign for a correction story and well inside noise. Absolute movement did not rise meaningfully in larger residual buckets. There is no stable "actual opener is off, then the close corrects toward fair" pattern.

The headline correction rate counts only games whose spread moved. CFB was exactly chance: 229 aligned of 458 moved games. NFL was 34 of 61, far too small to separate from chance. If unchanged closes are included as failures, rates are 37.7% and 40.0%.

## Method

- Separate CFB and NFL ridge fair-opener models. No pooling.
- Target: home-team ESPN BET opening spread.
- Features: team identity difference, home/neutral, rest difference when available, capped week, and NFL divisional indicator. Only pregame schedule/context fields.
- Explicit source allowlists excluded score, result, winner and all postgame statistics.
- Outer validation predicted later weeks from earlier 2025 weeks only. Ridge strength was selected inside each fold from earlier weeks only. First scored weeks were week 4 CFB and week 8 NFL after minimum training-size rules.
- Residual = actual opener minus predicted fair opener. Validation target = same-provider close minus open. No outcome entered fitting, selection, scoring or interpretation.

## Interpretation

This did what a single-season market-imitation test should do: it tried to reconstruct the archived pricing function. It did not produce a usable line-movement signal. The CFB fit is too coarse around team identity and the NFL archive is especially thin and stops at 193 ESPN BET regular-season pairs. A more flexible fit might reproduce the same-season opener more closely, but without multiple timestamped seasons it would increase leakage/overfit risk and would not turn this null residual result into evidence of an edge.

Do not surface residuals as picks, confidence, or approved bets. The result does not apply to FanDuel. The next honest test is the prospective, timestamped FanDuel capture already running; it can establish true first-seen line, movement and book fidelity.
