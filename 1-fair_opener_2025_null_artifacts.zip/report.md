# 2025 fair-opener data coverage report

## Bottom line

A free fit is technically possible using ESPN-labelled opening spreads, but it cannot meet a strict timestamp-audited definition of "the opener," and it cannot be described as a FanDuel opener model. ESPN exposes provider-specific `open` and `close` snapshots without observed-at timestamps. This is usable for exploratory market-imitation work only.

## Measured coverage

The audit queried ESPN's archived odds endpoint game by game on September 2, 2026.

| League | 2025 universe | Any paired opening spread | Same-provider open + close | Best stable provider pair |
|---|---:|---:|---:|---:|
| CFB, FBS-vs-FBS | 808 | 808 (100%) | 807 (99.88%) | ESPN BET: 751 (92.95%) |
| NFL, including postseason | 285 | 285 (100%) | 285 (100%) | ESPN BET: 193 (67.72%) |

DraftKings supplies a smaller clean pair: 101 CFB games (12.50%) and 105 NFL games (36.84%). The apparent 100% "any provider" coverage changes provider across games, so it is not a single-book series. ESPN's separate `- Live Odds` providers often have an `open` but no `close`; those records should not be silently joined to the static provider.

## Trust assessment

- **Game identity and current retrievability: high.** ESPN game IDs join directly to the free SportsDataverse CFB schedule and nflverse NFL schedule.
- **Open/close labels: medium.** The archive explicitly labels nested snapshots `open`, `close`, and `current`, and values show plausible movement.
- **Opening timestamp: low / unverifiable.** The documented output contains no timestamp. We cannot prove when the open was first observed, whether it was the first market number, or whether ESPN later repaired it.
- **Book fidelity: medium for ESPN BET and DraftKings, none for FanDuel.** No FanDuel 2025 series is present. A changing-provider aggregate is not book-specific.
- **Leakage boundary:** outcomes are not needed to retrieve, fit, or validate this task. Schedule fields must be limited to pregame facts; nflverse score/result and postgame fields must be excluded even though they share the source file.

## Recommendation before fitting

Freeze an exploratory specification that uses only the same-provider ESPN BET open-to-close pairs: 751 CFB games and 193 NFL games. Fit leagues separately because football scale, team identity, roster turnover, and market timing differ. Do not pool raw CFB and NFL rows into one model. Use schedule/context and lagged market/team state only, with no result, score, or postgame stat fields.

Evaluate actual opener minus predicted fair opener against signed open-to-close movement using season-forward folds, not random folds. Label the output: **"market imitation / line-movement research; no outcomes; no claim of beating the market; opener timestamps unavailable; not FanDuel-specific."** A model trained to reproduce openers can at best replicate this archived pricing function. It cannot establish predictive accuracy or betting edge.

If Garrett requires a timestamp-verifiable first FanDuel opener, free coverage is not enough. That needs a purchased historical feed or an already-running prospective capture. Do not buy one without approval.
