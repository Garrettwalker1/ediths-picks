# Sources
- ESPN/cfbfastR game odds documentation: https://cfbfastr.sportsdataverse.org/reference/espn_cfb_game_odds.html - documents per-provider `open`, `close`, `current`; no timestamp field in long schema. High confidence.
- ESPN Core v2 odds endpoint, queried for each 2025 game (example): https://sports.core.api.espn.com/v2/sports/football/leagues/college-football/events/401628339/competitions/401628339/odds?lang=en&region=us - live archive payload. High confidence for current retrievability, medium for semantics/timing.
- SportsDataverse season-specific CFB schedule/team releases: https://github.com/sportsdataverse/sportsdataverse-data/releases/tag/espn_cfb_schedules and https://github.com/sportsdataverse/sportsdataverse-data/releases/tag/espn_cfb_teams - coverage denominators/FBS membership.
- nflverse game data: https://github.com/nflverse/nfldata/blob/master/data/games.csv - 2025 NFL schedule/ESPN IDs and closing consensus only; no opener. High confidence.
- Scottfree schema: https://scottfreellc.github.io/alphapy-sports/data/schema.html - paid data; defines opener as first observed price of day, columns added 2026; not free full season.
- Hugging Face sample: https://huggingface.co/datasets/oliviersportsdata/NFL-Multi-Market-Odds-Team-Stats - only 12 games/season, full archive sold commercially. Not usable for coverage.
