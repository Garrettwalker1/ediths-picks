#!/usr/bin/env python3
import json,csv,sys,uuid,datetime,statistics
BOOKS=['betmgm','bet365','draftkings','fanduel','fanatics','bet_rivers_co','caesars']
NAMES={'betmgm':'BetMGM','bet365':'bet365','draftkings':'DraftKings','fanduel':'FanDuel','fanatics':'Fanatics','bet_rivers_co':'BetRivers','caesars':'Caesars'}
def load(path):
 x=json.load(open(path)); raw=x.get('structured',x.get('content')); return json.loads(raw) if isinstance(raw,str) else raw
def extract(path,sport,market,observed):
 x=load(path); tabs=x['props']['pageProps']['oddsTables']; rows=[]
 for tab in tabs:
  for g in tab['oddsTableModel']['gameRows']:
   v=g['gameView']; gid=str(v['gameId']); teams=[v['awayTeam']['displayName'],v['homeTeam']['displayName']]; qs=[]
   for o in g['oddsViews']:
    if not o: continue
    if o['sportsbook'] not in BOOKS:continue
    cur=o['currentLine'];op=o['openingLine']
    for side,team in [('away',teams[0]),('home',teams[1])]:
     if market=='side': line=cur.get(side+'Spread');price=cur.get(side+'Odds');oline=op.get(side+'Spread')
     else: line=cur.get('total');price=cur.get('overOdds' if side=='away' else 'underOdds');oline=op.get('total');team='over' if side=='away' else 'under'
     if line is None or price is None:continue
     qs.append(dict(book=NAMES[o['sportsbook']],selection=team,line=float(line),price=int(price),opening_line=oline))
   for selection in set(q['selection'] for q in qs):
    z=[q for q in qs if q['selection']==selection];lines=[q['line'] for q in z];med=statistics.median(lines);mad=statistics.median(abs(a-med) for a in lines);sg=str(uuid.uuid5(uuid.NAMESPACE_URL,f'{sport}/{gid}/{market}/{selection}/{observed}'))
    for q in z: rows.append(dict(snapshot_group_id=sg,quote_id=str(uuid.uuid4()),captured_at=observed,source='SportsbookReview',source_updated_at='',sport=sport,game_id=gid,kickoff=v['startDate'],book=q['book'],market=market,selection=selection,line=q['line'],american_price=q['price'],implied_probability='',no_vig_probability='',quote_status='displayed',first_observed='',consensus_line=med,line_range=max(lines)-min(lines),line_mad=mad,book_count=len(z),fanduel_line_vs_consensus=(q['line']-med if q['book']=='FanDuel' else ''),weeknight='',conference_tier='',visibility_proxy='',model_version='v3-forward-measurement',opening_line=q['opening_line']))
 return rows
if __name__=='__main__':
 observed=datetime.datetime.now(datetime.timezone.utc).replace(microsecond=0).isoformat().replace('+00:00','Z'); rows=[]
 for p,s,m in zip(sys.argv[1::3],sys.argv[2::3],sys.argv[3::3]):rows+=extract(p,s,m,observed)
 out=sys.stdout; w=csv.DictWriter(out,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
